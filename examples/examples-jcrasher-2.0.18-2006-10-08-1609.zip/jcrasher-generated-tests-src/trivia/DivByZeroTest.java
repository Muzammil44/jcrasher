package trivia;

/**
 * No comment
 */
public class DivByZeroTest extends junit.framework.TestCase {
  
  /**
   * Executed before each testXXX().
   */
  protected void setUp() {
    //TODO: my setup code goes here.
  }
  
  /**
   * Executed after each testXXX().
   */
  protected void tearDown() throws Exception {
    super.tearDown();
    //TODO: my tear down code goes here.
  }

  public void test0() throws Throwable {
    int i1 = 0;
    DivByZero.inverse(i1);
  }
  
  
  public DivByZeroTest(String pName) {
    super(pName);
  }
  
  public static junit.framework.Test suite() {
    return new junit.framework.TestSuite(DivByZeroTest.class);
  }
  
  public static void main(String[] args) {
    junit.textui.TestRunner.run(DivByZeroTest.class);
  }
}