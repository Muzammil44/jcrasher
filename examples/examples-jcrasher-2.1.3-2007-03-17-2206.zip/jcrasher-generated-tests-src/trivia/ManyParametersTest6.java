package trivia;

/**
 * Test cases for sum
 */
public class ManyParametersTest6 extends edu.gatech.cc.junit.FilteringTestCase {
  
  /**
   * Executed before each testXXX().
   */
  protected void setUp() {
    /* Re-initialize static fields of loaded classes. */
    edu.gatech.cc.junit.reinit.ClassRegistry.resetClasses();
    //TODO: my setup code goes here.
  }
  
  /**
   * Executed after each testXXX().
   */
  protected void tearDown() throws Exception {
    super.tearDown();
    //TODO: my tear down code goes here.
  }

  /**
   * JCrasher-generated test case.
   */
  public void test0() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test1() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test2() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test3() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test4() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test5() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test6() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test7() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test8() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test9() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test10() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test11() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test12() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test13() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test14() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test15() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test16() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test17() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test18() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test19() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test20() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test21() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test22() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test23() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test24() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test25() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test26() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test27() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test28() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test29() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test30() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test31() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test32() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test33() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test34() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test35() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test36() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test37() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test38() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test39() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test40() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test41() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test42() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test43() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test44() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test45() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test46() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test47() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test48() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test49() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test50() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test51() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test52() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test53() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test54() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test55() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test56() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test57() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test58() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test59() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test60() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test61() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test62() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test63() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test64() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test65() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test66() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test67() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test68() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test69() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test70() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test71() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test72() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test73() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test74() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test75() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test76() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test77() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test78() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test79() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test80() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test81() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test82() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test83() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test84() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test85() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test86() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test87() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test88() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test89() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test90() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test91() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test92() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test93() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test94() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test95() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test96() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test97() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test98() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test99() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test100() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test101() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test102() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test103() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test104() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test105() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test106() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test107() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test108() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test109() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test110() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test111() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test112() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test113() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test114() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test115() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test116() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test117() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test118() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test119() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test120() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test121() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test122() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test123() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test124() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test125() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test126() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test127() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test128() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test129() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test130() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test131() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test132() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test133() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test134() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test135() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test136() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test137() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test138() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test139() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test140() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test141() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test142() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test143() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test144() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test145() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test146() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test147() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test148() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test149() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test150() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test151() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test152() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test153() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test154() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test155() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test156() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test157() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test158() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test159() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test160() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test161() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test162() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test163() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test164() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test165() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test166() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test167() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test168() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test169() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test170() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test171() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test172() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test173() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test174() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test175() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test176() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test177() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test178() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test179() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test180() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test181() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test182() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test183() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test184() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test185() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test186() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test187() throws Throwable {
    try{
      int i1 = 1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Throwable throwable) {throwIf(throwable);}
  }
  
  
  protected String getNameOfTestedMeth() {
    return "trivia.ManyParameters.sum";
  }
  
  /**
   * Constructor
   */
  public ManyParametersTest6(String pName) {
    super(pName);
  }
  
  /**
   * Easy access for aggregating test suite.
   */
  public static junit.framework.Test suite() {
    return new junit.framework.TestSuite(ManyParametersTest6.class);
  }
  
  /**
   * Main
   */
  public static void main(String[] args) {
    junit.textui.TestRunner.run(ManyParametersTest6.class);
  }
}