/*
 * ManyParameters.java
 * 
 * Copyright 2007 Christoph Csallner and Yannis Smaragdakis.
 */
package trivia;

/**
 * @author csallner@gatech.edu (Christoph Csallner)
 */
public class ManyParameters {
	
	/**
	 * @return sum of parameters
	 */
	public int sum(int a, int b, int c, int d, int e, int f, int g) {
		return a + b + c + d + e + f + g;
	}
}
