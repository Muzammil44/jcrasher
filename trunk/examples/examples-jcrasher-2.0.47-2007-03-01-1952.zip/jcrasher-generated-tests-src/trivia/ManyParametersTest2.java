package trivia;

/**
 * no comment
 */
public class ManyParametersTest2 extends edu.gatech.cc.junit.FilteringTestCase {
  
  /**
   * Executed before each testXXX().
   */
  protected void setUp() {
    /* Re-initialize static fields of loaded classes. */
    edu.gatech.cc.junit.reinit.ClassRegistry.resetClasses();
    //TODO: my setup code goes here.
  }
  
  /**
   * Executed after each testXXX().
   */
  protected void tearDown() throws Exception {
    super.tearDown();
    //TODO: my tear down code goes here.
  }

  /**
   * JCrasher-generated test case.
   */
  public void test0() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test1() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test2() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test3() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test4() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test5() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test6() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test7() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test8() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test9() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test10() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test11() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test12() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test13() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test14() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test15() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test16() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test17() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test18() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test19() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test20() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test21() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test22() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test23() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test24() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test25() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test26() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test27() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test28() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test29() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test30() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test31() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test32() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test33() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test34() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test35() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test36() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test37() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test38() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test39() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test40() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test41() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test42() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test43() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test44() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test45() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test46() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test47() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test48() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test49() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test50() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test51() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test52() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test53() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test54() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test55() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test56() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test57() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test58() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test59() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test60() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test61() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test62() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test63() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test64() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test65() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test66() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test67() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test68() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test69() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test70() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test71() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test72() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test73() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test74() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test75() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test76() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test77() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test78() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test79() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test80() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test81() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test82() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test83() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test84() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test85() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test86() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test87() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test88() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test89() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test90() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test91() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test92() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test93() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test94() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test95() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test96() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test97() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test98() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test99() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test100() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test101() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test102() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test103() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test104() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test105() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test106() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test107() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test108() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test109() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test110() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test111() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test112() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test113() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test114() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test115() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test116() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test117() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test118() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test119() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test120() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test121() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test122() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test123() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test124() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test125() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test126() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test127() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test128() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test129() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test130() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test131() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test132() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test133() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test134() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test135() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test136() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test137() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test138() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test139() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test140() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test141() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test142() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test143() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test144() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test145() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test146() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test147() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test148() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test149() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test150() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test151() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test152() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test153() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test154() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test155() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test156() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test157() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test158() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test159() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test160() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test161() throws Throwable {
    try{
      int i1 = -1;
      int i2 = 1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test162() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test163() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test164() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test165() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test166() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test167() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test168() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test169() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test170() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test171() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test172() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test173() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test174() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test175() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test176() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test177() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test178() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test179() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test180() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test181() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test182() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test183() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test184() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test185() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test186() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test187() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test188() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test189() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test190() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test191() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test192() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test193() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test194() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test195() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test196() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test197() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test198() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test199() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test200() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test201() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test202() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test203() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test204() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test205() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test206() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test207() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test208() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test209() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test210() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test211() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test212() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test213() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test214() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test215() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test216() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test217() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test218() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test219() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test220() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test221() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test222() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test223() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test224() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test225() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test226() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test227() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test228() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test229() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test230() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test231() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test232() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test233() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test234() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test235() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test236() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test237() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test238() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test239() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test240() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test241() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test242() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test243() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test244() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test245() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test246() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test247() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test248() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test249() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test250() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test251() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test252() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test253() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test254() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test255() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test256() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test257() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test258() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test259() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test260() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test261() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test262() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test263() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test264() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test265() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test266() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test267() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test268() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test269() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test270() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test271() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test272() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test273() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test274() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test275() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test276() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test277() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test278() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test279() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test280() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test281() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test282() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test283() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test284() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test285() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test286() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test287() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test288() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test289() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test290() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test291() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test292() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test293() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test294() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test295() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test296() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test297() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test298() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test299() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test300() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test301() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test302() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test303() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test304() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test305() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test306() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test307() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test308() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test309() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test310() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test311() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test312() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 0;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test313() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test314() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test315() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test316() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test317() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test318() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test319() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test320() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test321() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test322() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test323() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test324() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test325() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test326() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test327() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test328() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test329() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test330() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test331() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test332() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test333() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test334() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test335() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test336() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test337() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test338() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test339() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test340() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test341() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test342() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test343() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test344() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test345() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test346() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test347() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test348() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test349() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test350() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test351() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test352() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test353() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test354() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test355() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test356() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test357() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test358() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test359() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test360() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test361() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test362() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test363() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test364() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test365() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test366() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test367() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test368() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test369() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test370() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test371() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test372() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test373() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test374() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test375() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test376() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test377() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test378() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test379() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test380() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test381() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test382() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test383() throws Throwable {
    try{
      int i1 = 0;
      int i2 = -1;
      int i3 = 1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test384() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test385() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test386() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test387() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test388() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test389() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test390() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test391() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test392() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test393() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test394() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test395() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test396() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test397() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test398() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test399() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test400() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test401() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test402() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test403() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test404() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test405() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test406() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test407() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test408() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test409() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test410() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test411() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test412() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test413() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test414() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test415() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test416() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test417() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test418() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test419() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test420() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test421() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test422() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test423() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test424() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test425() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test426() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test427() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test428() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test429() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test430() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test431() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 0;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test432() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test433() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test434() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test435() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test436() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test437() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test438() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test439() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test440() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test441() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test442() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test443() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test444() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test445() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test446() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test447() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test448() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test449() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test450() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test451() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test452() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test453() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test454() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test455() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test456() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = -1;
      int i4 = 1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test457() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test458() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test459() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test460() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test461() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test462() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test463() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test464() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test465() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test466() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test467() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test468() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test469() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test470() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test471() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test472() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test473() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test474() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test475() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test476() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test477() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test478() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test479() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test480() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test481() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = -1;
      int i5 = 1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test482() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test483() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test484() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test485() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test486() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test487() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test488() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test489() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test490() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = -1;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test491() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test492() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test493() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = -1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test494() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test495() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test496() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test497() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 0;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test498() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 1;
      int i7 = 1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }

  /**
   * JCrasher-generated test case.
   */
  public void test499() throws Throwable {
    try{
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 1;
      int i6 = -1;
      int i7 = -1;
      ManyParameters m8 = new ManyParameters();
      m8.sum(i1, i2, i3, i4, i5, i6, i7);
    }
    catch (Exception e) {dispatchException(e);}
  }
  
  
  protected String getNameOfTestedMeth() {
    return "trivia.ManyParameters.sum";
  }
  
  /**
   * Constructor
   */
  public ManyParametersTest2(String pName) {
    super(pName);
  }
  
  /**
   * Easy access for aggregating test suite.
   */
  public static junit.framework.Test suite() {
    return new junit.framework.TestSuite(ManyParametersTest2.class);
  }
  
  /**
   * Main
   */
  public static void main(String[] args) {
    junit.textui.TestRunner.run(ManyParametersTest2.class);
  }
}